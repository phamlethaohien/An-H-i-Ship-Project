<style type="text/css">
#hero {
  height: 100vh !important;
}
</style>

<?php get_header(); ?>

<main id="main">
  <?php get_template_part( 'template-parts/home/content', 'home' ); ?>
</main>

<?php get_footer(); ?>
