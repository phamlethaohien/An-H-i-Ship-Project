<section id="page" class="page">
	<div class="container" data-aos="fade-up">  
		<?php comments_template(); ?>
	</div>
</section>
