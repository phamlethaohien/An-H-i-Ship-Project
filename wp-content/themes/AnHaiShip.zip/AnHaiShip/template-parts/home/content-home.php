<!-- ======= About Section ======= -->
<section id="about" class="about">
  <div class="container" data-aos="fade-up">

    <div class="row">
      <div class="col-lg-6 order-1 order-lg-2" data-aos="fade-left" data-aos-delay="100">
      <img class="img-fluid"
               style=""
               src="<?php echo esc_url( get_theme_file_uri( '/assets/images/AnHaiShip/anhai_1.jpg' ) ) ?>"
               alt="<?php the_title(); ?>"
          />
      </div>
      <div class="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content" data-aos="fade-right" data-aos-delay="100">
        <h3>Công ty TNHH Dịch vụ và Thương mại vận tải An Hải</h3>
        <p class="ri-check-double-line">
          Được thành lập từ ngày 12/8/2009. Mã số doanh nghiệp 0200964322. Với hơn 10 năm thành lập đến nay, chúng tôi không ngừng nỗ lực mở rộng, phát triển đầu tư, quản lý và sở hữu đội tàu hiện tại, trọng tải lớn nhằm đảm bảo tàu hoạt động các tuyến trong nước và quốc tế từ 5.000DWT cho đến 53.000DWT.
        </p>
    
        <p class="ri-check-double-line">
          Chúng tôi luôn tin rằng trách nhiệm hàng đầu của mình là không chỉ đáp ứng nhu cầu mà còn đem đến sự hài lòng tuyệt đối cho khách hàng khi sử dụng dịch vụ của Công ty.
        </p>
            <!-- <ul>
          <li><i class="ri-check-double-line fst-italic"></i> Ullamco laboris nisi ut aliquip ex ea commodo consequat.</li>
          <li><i class="ri-check-double-line"></i> Duis aute irure dolor in reprehenderit in voluptate velit.</li>
          <li><i class="ri-check-double-line"></i> Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate trideta storacalaperda mastiro dolore eu fugiat nulla pariatur.</li>
        </ul> -->
      </div>
    </div>

  </div>
</section><!-- End About Section -->

<!-- ======= Clients Section ======= -->



<section> 
    <div class="rt-container">
    	<div class="col-rt-12">
  <!-- Slider -->
          <div id="slider">
            <div class="slides">
              <div class="slider">
                <div class="legend"></div>
                <div class="content-slide">
                  <div class="content-txt">
                    <h2>Hệ Thống Tàu Biển Chất Lượng Cao</h2>
                    <p>Dich vụ kinh doanh vận tải hàng hóa ven biển và viễn dương đáp ứng
                    nhu cầu của khách hàng trong suốt thời gian dài.</p>
                  </div>
                </div>
                <div class="image-slide"> <img src="wp-content/themes/AnHaiShip/assets/images/AnHaiShip/anhai_3.jpg" class="img-fluid d-block w-100" alt=""> </div>
              </div>
              <div class="slider">
                <div class="legend"></div>
                <div class="content-slide">
                  <div class="content-txt">
                    <h2>Dịch vụ vận chuyển hàng hóa, quản lý khai thác tàu</h2>
                    <p>Nam ultrices pellentesque facilisis. In semper tellus mollis nisl pulvinar vitae vulputate lorem consequat. Fusce odio tortor, pretium sit amet auctor ut, ultrices vel nibh.</p>
                  </div>
                </div>
                <div class="image-slide"><img src="wp-content/themes/AnHaiShip/assets/images/AnHaiShip/anhai_2.jpg" class="img-fluid d-block w-100" alt=""> </div>
              </div>
              <div class="slider">
                <div class="legend"></div>
                <div class="content-slide">
                  <div class="content-txt">
                    <h2>Hệ Thống Tàu Biển Chất Lượng Cao</h2>
                    <p>Nam ultrices pellentesque facilisis. In semper tellus mollis nisl pulvinar vitae vulputate lorem consequat. Fusce odio tortor, pretium sit amet auctor ut, ultrices vel nibh.</p>
                  </div>
                </div>
                <div class="image-slide"> <img src="wp-content/themes/AnHaiShip/assets/images/AnHaiShip/anhai_4.jpg" class="img-fluid d-block w-100" alt=""> </div>
              </div>
              <div class="slider">
                <div class="legend"></div>
                <div class="content-slide">
                  <div class="content-txt">
                    <h2>Dịch vụ vận chuyển hàng hóa, quản lý khai thác tàu</h2>
                    <p>Nam ultrices pellentesque facilisis. In semper tellus mollis nisl pulvinar vitae vulputate lorem consequat. Fusce odio tortor, pretium sit amet auctor ut, ultrices vel nibh.</p>
                  </div>
                </div>
                <div class="image-slide"> <img src="wp-content/themes/AnHaiShip/assets/images/AnHaiShip/anhai_5.jpg" class="img-fluid d-block w-100" alt=""> </div>
              </div>
            </div>
            <div class="switch">
              <ul>
                <li>
                  <div class="on"></div>
                </li>
                <li></li>
                <li></li>
                <li></li>
              </ul>
            </div>
          </div>
         </div> 
	 </div>          
</section>

<!-- End Clients Section -->

<!-- ======= Features Section ======= -->
<section id="features" class="features">
  <div class="container" data-aos="fade-up">

    <div class="row">
      <div class="image col-lg-6" 
      style='background-image: url("wp-content/themes/AnHaiShip/assets/images/AnHaiShip/anhai_5.jpg");' data-aos="fade-right"></div>
      <div class="col-lg-6" data-aos="fade-left" data-aos-delay="100">
        <div class="icon-box mt-5 mt-lg-0" data-aos="zoom-in" data-aos-delay="150">
          <i class="bx bx-receipt"></i>
          <h4>Quá trình hình thành</h4>
          <p>Được thành lập từ ngày 12/8/2009. Mã số doanh nghiệp: 0200964322. Với hơn 10 năm thành lập đến nay, chúng tôi không ngừng nỗ lực mở rộng, phát triển đầu tư, quản lí và sở hữu đội tàu hiện đại, trọng tải lớn nhằm đảm bảo tàu hoạt động các tuyến trong nước và quốc tế từ 5.000DWT cho đến 53.000 DWT…</p>
        </div>
        <div class="icon-box mt-5" data-aos="zoom-in" data-aos-delay="150">
          <i class="bx bx-calendar"></i>
          <h4>2000</h4>
          <h4>Ngày đầu thành lập vận tải An Hải</h4>
          <p>Được thành lập từ ngày 12/8/2009. Mã số doanh nghiệp: 0200964322. Với hơn 10 năm thành lập đến nay, chúng tôi không ngừng nỗ lực mở rộng, phát triển đầu tư, quản lí và sở hữu đội tàu hiện đại, trọng tải lớn nhằm đảm bảo tàu hoạt động các tuyến trong nước và quốc tế từ 5.000DWT cho đến 53.000 DWT…</p>
        </div>
        <div class="icon-box mt-5" data-aos="zoom-in" data-aos-delay="150">
          <i class="bx bx-calendar"></i>
          <h4>2010</h4>
          <h4>Định hướng & phát triển lâu dài</h4>
          <p>Được thành lập từ ngày 12/8/2009. Mã số doanh nghiệp: 0200964322. Với hơn 10 năm thành lập đến nay, chúng tôi không ngừng nỗ lực mở rộng, phát triển đầu tư, quản lí và sở hữu đội tàu hiện đại, trọng tải lớn nhằm đảm bảo tàu hoạt động các tuyến trong nước và quốc tế từ 5.000DWT cho đến 53.000 DWT…</p>
        </div>
        <div class="icon-box mt-5" data-aos="zoom-in" data-aos-delay="150">
          <i class="bx bx-calendar"></i>
          <h4>2021</h4>
          <h4>Vươn tầm thế giới</h4>
          <p>Được thành lập từ ngày 12/8/2009. Mã số doanh nghiệp: 0200964322. Với hơn 10 năm thành lập đến nay, chúng tôi không ngừng nỗ lực mở rộng, phát triển đầu tư, quản lí và sở hữu đội tàu hiện đại, trọng tải lớn nhằm đảm bảo tàu hoạt động các tuyến trong nước và quốc tế từ 5.000DWT cho đến 53.000 DWT…</p>
        </div>
      </div>
    </div>

  </div>
</section>
<!-- End Features Section -->

<!-- ======= Services Section ======= -->
<section id="services" class="services">
  <div class="container" data-aos="fade-up">

    <div class="section-title">
      <h2>Services</h2>
      <p>Lĩnh vực hoạt động</p>
    </div>

    <div class="row">
      <div class="col-lg-4 col-md-6 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="100">
        <div class="icon-box">
          <div class="icon"><img src="wp-content/themes/AnHaiShip/assets/images/icon_action/icon_01.png" class="img-fluid" alt=""></div>
          <h4><a href="">Vận tải Quốc tế & Nội địa</a></h4>
          <p>Được thành lập từ ngày 12/8/2009. Mã số doanh nghiệp: 0200964322. Với hơn 10 năm thành lập đến nay, chúng tôi không ngừng nỗ lực mở rộng...</p>
        </div>
      </div>

      <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4 mt-md-0" data-aos="zoom-in" data-aos-delay="200">
        <div class="icon-box">
          <div class="icon"><img src="wp-content/themes/AnHaiShip/assets/images/icon_action/icon_02.png" class="img-fluid" alt=""></div>
          <h4><a href="">Logistic</a></h4>
          <p>Được thành lập từ ngày 12/8/2009. Mã số doanh nghiệp: 0200964322. Với hơn 10 năm thành lập đến nay, chúng tôi không ngừng nỗ lực mở rộng, phát triển đầu tư, quản lí và sở hữu đội tàu hiện đại</p>
        </div>
      </div>

      <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4 mt-lg-0" data-aos="zoom-in" data-aos-delay="300">
        <div class="icon-box">
          <div class="icon"><img src="wp-content/themes/AnHaiShip/assets/images/icon_action/icon_03.png" class="img-fluid" alt=""></div>
          <h4><a href="">Cho thuê tàu</a></h4>
          <p>Được thành lập từ ngày 12/8/2009. Mã số doanh nghiệp: 0200964322. Với hơn 10 năm thành lập đến nay, chúng tôi không ngừng nỗ lực mở rộng...</p>
        </div>
      </div>

      <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4" data-aos="zoom-in" data-aos-delay="100">
        <div class="icon-box">
          <div class="icon"><img src="wp-content/themes/AnHaiShip/assets/images/icon_action/icon_04.png" class="img-fluid" alt=""></div>
          <h4><a href="">Mua bán tàu</a></h4>
          <p>Được thành lập từ ngày 12/8/2009. Mã số doanh nghiệp: 0200964322. Với hơn 10 năm thành lập đến nay, chúng tôi không ngừng nỗ lực mở rộng...</p>
        </div>
      </div>

      <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4" data-aos="zoom-in" data-aos-delay="200">
        <div class="icon-box">
          <div class="icon"><img src="wp-content/themes/AnHaiShip/assets/images/icon_action/icon_05.png" class="img-fluid" alt=""></div>
          <h4><a href="">Quản lý & Cung ứng thuyền viên</a></h4>
          <p>Được thành lập từ ngày 12/8/2009. Mã số doanh nghiệp: 0200964322. Với hơn 10 năm thành lập đến nay, chúng tôi không ngừng nỗ lực mở rộng...</p>
        </div>
      </div>

      <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4" data-aos="zoom-in" data-aos-delay="300">
        <div class="icon-box">
          <div class="icon"><i class="bx bx-file"></i></div>
          <h4><a href="">Dịch vụ khác</a></h4>
          <p>Được thành lập từ ngày 12/8/2009. Mã số doanh nghiệp: 0200964322. Với hơn 10 năm thành lập đến nay, chúng tôi không ngừng nỗ lực mở rộng...</p>
        </div>
      </div>

    </div>

  </div>
</section><!-- End Services Section -->

<!-- ======= Portfolio Section ======= -->
<section id="portfolio" class="portfolio">
  <div class="container" data-aos="fade-up">
    <div class="section-title">
      <h2>Thư viện</h2>
      <p>Hình ảnh & Video</p>
    </div>
    <div class="row" data-aos="fade-up" data-aos-delay="100">
      <div class="col-lg-12 d-flex justify-content-center">
        <ul id="portfolio-flters">
          <li data-filter="*" class="filter-active">All</li>
          <li data-filter=".filter-app">Ảnh</li>
          <li data-filter=".filter-card">Video</li>
          <li data-filter=".filter-web">Chúng tôi</li>
        </ul>
      </div>
    </div>
    <div class="row portfolio-container" data-aos="fade-up" data-aos-delay="200">
      <div class="col-lg-4 col-md-6 portfolio-item filter-app">
        <div class="portfolio-wrap">
          <img src="wp-content/themes/AnHaiShip/assets/images/AnHaiShip/anhai_5.jpg.jpg" class="img-fluid" alt="">
          <div class="portfolio-info">
            <h4>Ảnh 1</h4>
            <p>Ảnh</p>
            <div class="portfolio-links">
              <a href="wp-content/themes/AnHaiShip/assets/images/AnHaiShip/anhai_5.jpg.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="App 1"><i class="bx bx-plus"></i></a>
              <a href="portfolio-details.html" title="More Details"><i class="bx bx-link"></i></a>
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-6 portfolio-item filter-web">
        <div class="portfolio-wrap">
          <img src="wp-content/themes/AnHaiShip/assets/images/portfolio/portfolio_3.jpg" class="img-fluid" alt="">
          <div class="portfolio-info">
            <h4>Chúng tôi 3</h4>
            <p>Chúng tôi</p>
            <div class="portfolio-links">
              <a href="wp-content/themes/AnHaiShip/assets/images/portfolio/portfolio_3.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Web 3"><i class="bx bx-plus"></i></a>
              <a href="portfolio-details.html" title="More Details"><i class="bx bx-link"></i></a>
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-6 portfolio-item filter-app">
        <div class="portfolio-wrap">
          <img src="wp-content/themes/AnHaiShip/assets/images/portfolio/portfolio_2.jpg" class="img-fluid" alt="">
          <div class="portfolio-info">
            <h4>Ảnh 2</h4>
            <p>Ảnh</p>
            <div class="portfolio-links">
              <a href="wp-content/themes/AnHaiShip/assets/images/portfolio/portfolio_2.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="App 2"><i class="bx bx-plus"></i></a>
              <a href="portfolio-details.html" title="More Details"><i class="bx bx-link"></i></a>
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-6 portfolio-item filter-card">
        <div class="portfolio-wrap">
          <img src="wp-content/themes/AnHaiShip/assets/images/AnHaiShip/anhai_2.jpg" class="img-fluid" alt="">
          <div class="portfolio-info">
            <h4>Video 2</h4>
            <p>Video</p>
            <div class="portfolio-links">
              <a href="wp-content/themes/AnHaiShip/assets/images/AnHaiShip/anhai_2.jpg.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Card 2"><i class="bx bx-plus"></i></a>
              <a href="portfolio-details.html" title="More Details"><i class="bx bx-link"></i></a>
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-6 portfolio-item filter-web">
        <div class="portfolio-wrap">
          <img src="wp-content/themes/AnHaiShip/assets/images/portfolio/portfolio_6.jpg" class="img-fluid" alt="">
          <div class="portfolio-info">
            <h4>Chúng tôi 2</h4>
            <p>Chúng tôi</p>
            <div class="portfolio-links">
              <a href="wp-content/themes/AnHaiShip/assets/images/portfolio/portfolio_6.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Web 2"><i class="bx bx-plus"></i></a>
              <a href="portfolio-details.html" title="More Details"><i class="bx bx-link"></i></a>
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-6 portfolio-item filter-app">
        <div class="portfolio-wrap">
          <img src="wp-content/themes/AnHaiShip/assets/images/AnHaiShip/anhai_1.jpg.jpg" class="img-fluid" alt="">
          <div class="portfolio-info">
            <h4>Ảnh 3</h4>
            <p>Ảnh</p>
            <div class="portfolio-links">
              <a href="wp-content/themes/AnHaiShip/assets/images/AnHaiShip/anhai_1.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="App 3"><i class="bx bx-plus"></i></a>
              <a href="portfolio-details.html" title="More Details"><i class="bx bx-link"></i></a>
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-6 portfolio-item filter-card">
        <div class="portfolio-wrap">
          <img src="wp-content/themes/AnHaiShip/assets/images/portfolio/portfolio_2.jpg" class="img-fluid" alt="">
          <div class="portfolio-info">
            <h4>Video 1</h4>
            <p>Video</p>
            <div class="portfolio-links">
              <a href="wp-content/themes/AnHaiShip/assets/images/portfolio/portfolio_2.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Card 1"><i class="bx bx-plus"></i></a>
              <a href="portfolio-details.html" title="More Details"><i class="bx bx-link"></i></a>
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-6 portfolio-item filter-card">
        <div class="portfolio-wrap">
          <img src="wp-content/themes/AnHaiShip/assets/images/portfolio/portfolio_3.jpg" class="img-fluid" alt="">
          <div class="portfolio-info">
            <h4>Video 3</h4>
            <p>Video</p>
            <div class="portfolio-links">
              <a href="wp-content/themes/AnHaiShip/assets/images/portfolio/portfolio_3.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Card 3"><i class="bx bx-plus"></i></a>
              <a href="portfolio-details.html" title="More Details"><i class="bx bx-link"></i></a>
            </div>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-6 portfolio-item filter-web">
        <div class="portfolio-wrap">
          <img src="wp-content/themes/AnHaiShip/assets/images/portfolio/portfolio_4.jpg" class="img-fluid" alt="">
          <div class="portfolio-info">
            <h4>Chúng tôi 3</h4>
            <p>Chúng tôi</p>
            <div class="portfolio-links">
              <a href="wp-content/themes/AnHaiShip/assets/images/portfolio/portfolio_4.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Web 3"><i class="bx bx-plus"></i></a>
              <a href="portfolio-details.html" title="More Details"><i class="bx bx-link"></i></a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section><!-- End Portfolio Section -->

<!-- ======= Cta Section ======= -->

<section id="cta" class="cta">
  <div class="container" data-aos="zoom-in">

    <div class="text-center">
      <h3>Tầm nhìn</h3>
      <p> Trở thành một trong những công ty vận tải biển hàng đầu khu vực Đông Nam Á đặc biệt trong lĩnh vực vận chuyển hàng khô rời, là đối tác tin cậy của khách hàng trên khắp thế giới qua việc cung cấp chất lượng dịch vụ ngày càng tốt hơn với giá cạnh tranh, liên tục đổi mới và tạo ra sự khác biệt trong các sản phẩm dịch vụ.</p>
      <h3>Sứ mệnh, tôn chỉ hoạt động</h3>
      <p>An Hải là doanh nghiệp chuyên vận chuyển hàng hoá khắp thế giới bằng đường biển. Với mong muốn đóng góp nhiều hơn vào chuỗi logistics toàn cầu, Chúng tôi còn tham gia hoạt động ở các lĩnh vực về dịch vụ hàng hải khác với chất lượng tốt và giá cả cạnh tranh.

Chúng tôi luôn tin rằng trách nhiệm hàng đầu của mình là không chỉ đáp ứng nhu cầu mà còn đem đến sự hài lòng tuyệt đối cho khách hàng khi sử dụng dịch vụ của Công ty. Vì thế chúng tôi luôn nỗ lực tái cấu trúc và hiện đại hóa, trẻ hoá đội tàu, xây dựng một hệ thống chất lượng cung cấp dịch vụ vận tải đạt hiệu quả cao và bảo vệ môi trường, hạn chế tối đa các rủi ro, đảm bảo quyền lợi cho các khách hàng. Chúng tôi luôn tìm mọi cách để nâng cao chất lượng dịch vụ, đa dạng hoá các loại hình kinh doanh, củng cố và phát triển thị trường …</p>
      
    </div>

  </div>
</section>
<!-- End Cta Section -->
<!-- ======= Counts Section ======= -->
<section id="counts" class="counts">
  <div class="container" data-aos="fade-up">
  <div class="container" data-aos="fade-up">
    <div class="section-title">
      <h2>Services</h2>
      <p>Thành Tích Ấn Tượng</p>
    </div>
    <div class="row no-gutters">
      <div class="col-xl-5 d-flex align-items-stretch justify-content-center justify-content-lg-start" data-aos="fade-right" data-aos-delay="100">
      <img src="wp-content/themes/AnHaiShip/assets/images/AnHaiShip/anhai_4.jpg" class="img-fluid" alt="">
      </div>
      
      <div class="col-xl-7 ps-0 ps-lg-5 pe-lg-1 d-flex align-items-stretch" data-aos="fade-left" data-aos-delay="100">
        <div class="content d-flex flex-column justify-content-center">
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Duis aute irure dolor in reprehenderit
          </p>
          <div class="row">
            <div class="col-md-6 d-md-flex align-items-md-stretch">
              <div class="count-box">
              <i class="bi bi-heart"></i>
                <span data-purecounter-start="0" data-purecounter-end="756" data-purecounter-duration="2" class="purecounter"></span>
                <p><strong>Khách hàng hài lòng</strong></p>
              </div>
            </div>

            <div class="col-md-6 d-md-flex align-items-md-stretch">
              <div class="count-box">
                <i class="bi bi-award"></i>
                <span data-purecounter-start="0" data-purecounter-end="1002" data-purecounter-duration="4" class="purecounter"></span>
                <p><strong>Tổng đơn hoàn thành</strong></p>
              </div>
            </div>

            <div class="col-md-6 d-md-flex align-items-md-stretch">
              <div class="count-box">
                <i class="bi bi-building"></i>
                <span data-purecounter-start="0" data-purecounter-end="8" data-purecounter-duration="4" class="purecounter"></span>
                <p><strong>Chi nhánh</strong></p>
              </div>
            </div>

            <div class="col-md-6 d-md-flex align-items-md-stretch">
              <div class="count-box">
                <i class="bi bi-people"></i>
                <span data-purecounter-start="0" data-purecounter-end="120" data-purecounter-duration="4" class="purecounter"></span>
                <p><strong>Đội ngũ nhân lực</strong></p>
              </div>
            </div>
          </div>
        </div><!-- End .content-->
      </div>
    </div>

  </div>
</section>
<!-- End Counts Section -->

<!-- ======= Contact Section ======= -->
<section id="contact" class="contact">
  <div class="container" data-aos="fade-up">
 
    <div class="section-title">
      <h2>Liên hệ</h2>
      <p>Liên hệ với chúng tôi</p>
    </div>
 
    <div>
      <iframe style="border:0; width: 100%; height: 270px;" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3728.971636379319!2d106.70990611492688!3d20.83285179981322!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x314a7aa87690f689%3A0x5baf7212e28486f0!2zVHJ1bmcgSMOgbmggNSwgxJDhurFuZyBMw6JtLCBI4bqjaSBBbiwgSOG6o2kgUGjDsm5nLCBWaeG7h3QgTmFt!5e0!3m2!1svi!2s!4v1625193331448!5m2!1svi!2s" frameborder="0" allowfullscreen></iframe>
    </div>
 
    <div class="row mt-5">
 
      <div class="col-lg-4">
        <div class="info">
          <div class="address">
            <i class="bi bi-geo-alt"></i>
            <h4>Địa chỉ:</h4>
            <p>Số 110, Lô 17 Mở Rộng, Đường Trung Hành 5, Phường Đằng Lâm, Quận Hải An, Thành phố Hải Phòng.</p>
          </div>
 
          <div class="email">
            <i class="bi bi-envelope"></i>
            <h4>Email:</h4>
            <p>chartering@anhaishipping.com.vn</p>
          </div>
 
          <div class="phone">
            <i class="bi bi-phone"></i>
            <h4>Điện thoại:</h4>
            <p>0225 8830218 | 0976 087 584</p>
          </div>
 
        </div>
 
      </div>
 
      <div class="col-lg-8 mt-5 mt-lg-0">
 
        <form action="forms/contact.php" method="post" role="form" class="php-email-form">
          <div class="row">
            <div class="col-md-6 form-group">
              <input type="text" name="name" class="form-control" id="name" placeholder="Họ và tên" required>
            </div>
            <div class="col-md-6 form-group mt-3 mt-md-0">
              <input type="email" class="form-control" name="email" id="email" placeholder="Email" required>
            </div>
          </div>
          <div class="form-group mt-3">
            <input type="text" class="form-control" name="subject" id="subject" placeholder="Chủ đề" required>
          </div>
          <div class="form-group mt-3">
            <textarea class="form-control" name="message" rows="5" placeholder="Nội dung" required></textarea>
          </div>
          <div class="my-3">
            <div class="loading">Loading</div>
            <div class="error-message"></div>
            <div class="sent-message">Your message has been sent. Thank you!</div>
          </div>
          <div class="text-center"><button type="submit">Gửi phản hồi</button></div>
        </form>
 
      </div>
 
    </div>
 
  </div>
</section><!-- End Contact Section -->

<script src="wp-content/themes/AnHaiShip/assets/js/main.js"></script>